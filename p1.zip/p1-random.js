/*
    CIT 281 Project 1
    Name: Diego Carpenter
*/

function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

let letters = "abcdefghijklmnopqrstuvwxyz";
let length = getRandomInteger(5, 26); 

let string = "";

for (let i = 0; i < length; i++) {
    let randomIndex = getRandomInteger(0, letters.length);
    let randomLetter = letters[randomIndex];
    string += randomLetter;
}

console.log(length + " lowercase letters: " + string); 
