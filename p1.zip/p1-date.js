/*
    CIT 281 Project 1
    Name: Diego Carpenter 
*/

console.log(["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][new Date().getDay()]);